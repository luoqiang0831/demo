;(function($){
	 $(document).bind('touchmove', function(e) {
          if (e.target === document.documentElement) {
            return e.preventDefault();
          }
        });
	$.fn.Cut=function(option){
		var $Map = this,
			scale=1,
			ScaleObj=function(obj,ScaleProp){obj.css("-webkit-transform","scale("+ScaleProp+")")},
			$warp=$(".warp"),
			warpH=$warp.height(),
			warpW=$warp.width(),
			GetMouse=function(obj){
				var print=[]
					for(var i=0;i<obj.touches.length;i++){
						print[i]={'pagex':obj.touches[i].pageX,'pagey':obj.touches[i].pageY};
					}
				return print;
			};
		$Map.on('touchstart',function(StartEv){
			var _this=$(this),
				StartPrint=GetMouse(StartEv),
				MovePrint=null,baseValue=0,
				scaleX=scale==1?0:(_this.width()/scale*(scale-1)/2),
				scaleY=scale==1?0:(_this.height()/scale*(scale-1)/2),
				OneThouchX=(scale==1?StartPrint[0]['pagex']-_this.position().left:StartPrint[0]['pagex']-_this.position().left-scaleX),
				OneThouchY=(scale==1?StartPrint[0]['pagey']-_this.position().top:StartPrint[0]['pagey']-_this.position().top-scaleY),
				MapH=_this.height(),
				MapW=_this.width();

		  _this.on('touchmove',function(MoveEv){
		  	if(MoveEv.touches.length==1){
		  		var moveX=MoveEv.touches[0].pageX-OneThouchX,
		  			moveY=MoveEv.touches[0].pageY-OneThouchY,
		  			movesX=moveX,movesY=moveY;
		  		if(moveX-scaleX>=0){
		  			movesX=scaleX;
		  		}else if(Math.abs(moveX)>MapW-warpW-scaleX){
		  			movesX=-(MapW-warpW-scaleX)
		  		}
		  		if(moveY-scaleY>=0){
		  			movesY=scaleY;
		  		}else if(Math.abs(moveY)>MapH-warpH-scaleY){
		  			movesY=-(MapH-warpH-scaleY)
		  		}
		  		_this.css({"left":movesX,"top":movesY});
		  		
		  		return false
		  	}
				MovePrint=GetMouse(MoveEv);
				
				var disX=MovePrint[0]['pagex']-MovePrint[1]['pagex'];
				var disY=MovePrint[0]['pagey']-MovePrint[1]['pagey'];
				var value=Math.sqrt(disX * disX + disY * disY);
				
				if(baseValue==0){
					baseValue=value
				}else{
					if (value - baseValue >= 10 || value - baseValue <= -10) {
                    var Sscale= value / baseValue;
                    //if(Sscale<1)return
                    if(Sscale<1&&scale>1)
                    	scale-=(scale-Sscale);
                    else
                    	scale=Sscale;

                    ScaleObj(_this,scale.toFixed(2))

                }
				}
				return false;
			})	
		  _this.on('touchend',function(EndEv){
			  if(scale<1){_this.css({"width":"100%","-webkit-transform":"scale(1)","left":0,"top":0});scale=1}
				_this.unbind('touchmove')
			})
	 
		})
		 $("#Cut").click(function(){
		 	var MapL= parseInt($Map.css('left')),MapT= parseInt($Map.css('top'));
		  	var ox=scale==1?MapL:(MapL-($Map.width()/scale*(scale-1)/2)).toFixed(2);
		  	var oy=scale==1?MapT:(MapT-($Map.height()/scale*(scale-1)/2)).toFixed(2);
		$.get("imgSave.htm?order_number="+order_number+"&mediaId="+mediaId+'&oWidth='+$Map[0].naturalWidth+'&oHeight='+$Map[0].naturalHeight+'&aWidth='+$Map.width()+'&aHeight='+$Map.height()+'&x='+ox+'&y='+oy+'&warpW='+warpW+'&warpH='+warpH,function(data){
				window.location.href="imgShow.htm?order_number="+order_number+"&mediaId="+mediaId;
			});
		  })
	}
})(Zepto);